jest.mock("bcrypt", () => ({
  __esModule: true,
  default: { compare: jest.fn() },
}));

import { UnauthorizedException } from "@nestjs/common";
import bcrypt from "bcrypt";
import { AuthService } from "./auth.service";

describe("AuthService banned account access", () => {
  const prisma = { user: { findUnique: jest.fn(), update: jest.fn() } };
  const jwtService = { sign: jest.fn().mockReturnValue("access-token") };
  const cacheManager = { set: jest.fn(), del: jest.fn() };
  const twoFactorService = {
    verifyToken: jest.fn().mockReturnValue(true),
    verifyBackupCode: jest.fn(),
  };
  const service = new AuthService(
    prisma as any,
    jwtService as any,
    cacheManager as any,
    twoFactorService as any,
  );

  beforeEach(() => {
    jest.clearAllMocks();
    (bcrypt.compare as jest.Mock).mockResolvedValue(true);
  });

  it("rejects banned users during password sign-in", async () => {
    prisma.user.findUnique.mockResolvedValue({
      email: "student@example.com",
      passwordHash: "hash",
      isBanned: true,
    });

    await expect(
      service.signIn({ email: "student@example.com", password: "password" }),
    ).rejects.toBeInstanceOf(UnauthorizedException);
    expect(jwtService.sign).not.toHaveBeenCalled();
    expect(cacheManager.set).not.toHaveBeenCalled();
  });

  it("rejects banned users when verifying a 2FA token", async () => {
    prisma.user.findUnique.mockResolvedValue({
      email: "student@example.com",
      isBanned: true,
      twoFactorEnabled: true,
      twoFactorSecret: "secret",
      twoFactorBackupCodes: [],
    });

    await expect(
      service.verify2faToken("student@example.com", "123456"),
    ).rejects.toBeInstanceOf(UnauthorizedException);
    expect(twoFactorService.verifyToken).not.toHaveBeenCalled();
    expect(jwtService.sign).not.toHaveBeenCalled();
  });
});
