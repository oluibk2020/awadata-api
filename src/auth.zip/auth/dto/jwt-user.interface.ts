// Define the user response type

export interface JwtUser {
  sub: string;
  email: string;
  firstName: string;
  lastName: string;
  mobile: string;
  role: string;
  
}
