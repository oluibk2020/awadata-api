jest.mock("node-fetch", () => jest.fn());
jest.mock("uuid", () => ({ v4: () => "test-reference" }));

import { UnauthorizedException } from "@nestjs/common";
import { JwtStrategy } from "./jwt.strategy";

describe("JwtStrategy banned account access", () => {
  const prisma = { user: { findUnique: jest.fn() } };
  const userService = { getUserByEmail: jest.fn() };
  const cacheManager = { get: jest.fn() };
  const configService = { get: jest.fn().mockReturnValue("secret") };
  const strategy = new JwtStrategy(
    prisma as any,
    configService as any,
    userService as any,
    cacheManager as any,
  );

  beforeEach(() => {
    jest.clearAllMocks();
    cacheManager.get.mockResolvedValue({ accessToken: "token" });
    prisma.user.findUnique.mockResolvedValue({ isBanned: false });
    userService.getUserByEmail.mockResolvedValue({
      id: "student-1",
      email: "student@example.com",
      firstName: "Ada",
      lastName: "Lovelace",
      mobile: "123",
      role: "USER",
    });
  });

  it("rejects a banned account even when its session is cached", async () => {
    prisma.user.findUnique.mockResolvedValue({ isBanned: true });

    await expect(
      strategy.validate({ email: "student@example.com" } as any),
    ).rejects.toBeInstanceOf(UnauthorizedException);
    expect(userService.getUserByEmail).not.toHaveBeenCalled();
  });

  it("continues validating an unbanned account", async () => {
    await expect(
      strategy.validate({ email: "student@example.com" } as any),
    ).resolves.toMatchObject({ sub: "student-1", role: "USER" });
  });
});
