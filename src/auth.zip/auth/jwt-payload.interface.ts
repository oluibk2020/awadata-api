export interface JwtPayload {
  email: string;
  firstName: string;
  lastName: string;
  mobile: string;
  role: string;
}
