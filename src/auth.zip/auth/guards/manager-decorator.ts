import { applyDecorators, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ManagerOrAdminGuard } from '../guards/manager.guards';

export function ManagerOrAdminOnly() {
  return applyDecorators(UseGuards(AuthGuard('jwt'), ManagerOrAdminGuard));
}
