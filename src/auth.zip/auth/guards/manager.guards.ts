import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
} from '@nestjs/common';
import { Observable } from 'rxjs';

@Injectable()
export class ManagerOrAdminGuard implements CanActivate {
  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    console.log(user);

    if (
      !user ||
      !user.role ||
      (user.role !== 'MANAGER' && user.role !== 'ADMIN')
    ) {
      throw new UnauthorizedException(
        'Only managers or administrators can access this resource',
      );
    }

    return true;
  }
}
